(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"NY_240x400_2_atlas_", frames: [[232,512,230,126],[242,128,230,126],[0,402,230,126],[0,0,240,400],[242,0,230,126],[242,256,230,126],[242,384,230,126]]}
];


// symbols:



(lib.d11_230 = function() {
	this.initialize(ss["NY_240x400_2_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.d12_230 = function() {
	this.initialize(ss["NY_240x400_2_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.d13_230 = function() {
	this.initialize(ss["NY_240x400_2_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.logos_240x400 = function() {
	this.initialize(ss["NY_240x400_2_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.m11_230 = function() {
	this.initialize(ss["NY_240x400_2_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.m12_230 = function() {
	this.initialize(ss["NY_240x400_2_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.m13_230 = function() {
	this.initialize(ss["NY_240x400_2_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.yellow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E40613").s().p("A1FKKIAA0TMAqLAAAIAAUTg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-135,-65,270,130);


(lib.Y = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FECC37").s().p("AiYMDQiXgeh/hVQiEhXhYiFQhYiFgdicQgdiVAeiYQAeiWBUiBQBXiDCEhZQCFhZCbgeQCUgcCXAeQCWAeB/BVQCEBXBYCFQBYCFAdCcQAdCVgeCYQgeCWhUCBQhXCDiEBZQiFBaibAdQhIAOhIAAQhNAAhNgQg");
	this.shape.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-78.2,-78.7,156.5,157.4);


(lib.shoes = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.d13_230();
	this.instance.parent = this;
	this.instance.setTransform(-115,-63);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-115,-63,230,126);


(lib.Raduga = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E12731").s().p("AiEOPIAAjeIvhAAIAADeIkjAAIAAoCICKAAQA0hsAghvQAih1AQiGQAQiPAIiYQAIigAAjRIAAitIRmAAIAAUbICQAAIAAICgAtAgJQggDmhFCwIJNAAIAAv3InGAAQAAFsgiD1gEA64AKxIhylkIo1AAIhxFkImEAAIJD4/IGpAAII2Y/gEA0KgHlIitIdIGXAAIiroYQgTg+gHhSIgJAAQgGBHgWBEgAb/KxIAA4/IO0AAIAAEkIpNAAIAAUbgAHQKxIEOoyIn5wNIGaAAIEAJVQAIATAdBwIAEAAQAPhRAUguIEFpZIF7AAIsUY/gA9jKxIhxlkIo2AAIhwFkImFAAIJE4/IGpAAII2Y/gEgkQgHlIitIdIGXAAIiroYQgTg+gIhSIgJAAQgGBHgVBEgEhA9AKxIAA4/IIxAAQJaAAAAH+QAADxitCVQitCUkgAAIirAAIAAIngEg7XgCGICNAAQEeAAAAj9QAAj3keAAIiNAAg");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-415.8,-91.1,831.7,182.3);


(lib.Rwhite = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AicINQjYhBhrjIQhrjIBBjZQBBjZDHhsQDHhrDXBBQDYBBBrDJQBrDHhBDZQhCDZjGBsQh8BDiCAAQhOAAhSgZg");
	this.shape.setTransform(0.025,-53.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-54.6,-108.9,109.30000000000001,109.9);


(lib.Rcopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E12731").s().p("AicINQjYhBhrjIQhrjIBBjZQBBjZDHhsQDHhrDXBBQDYBBBrDJQBrDHhBDZQhCDZjGBsQh8BDiCAAQhOAAhSgZg");
	this.shape.setTransform(0.025,-53.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-54.6,-108.9,109.30000000000001,109.9);


(lib.R = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E12731").s().p("AicINQjYhBhrjIQhrjIBBjZQBBjZDHhsQDHhrDXBBQDYBBBrDJQBrDHhBDZQhCDZjGBsQh8BDiCAAQhOAAhSgZg");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-54.6,-54.9,109.30000000000001,109.9);


(lib.Park = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E12731").s().p("EAnAAMiIptreQgjgngIgRIgFAAIAAMWIi8AAIAA5DIC8AAIAALyIAFAAQAQgZAbgeIJYq7IDrAAIqxMBILiNCgAFhMiIAA5DIG6AAQEBAACPB9QCNB+ABDkQAADkieCQQieCSkMAAIjTAAIAAJegAIeAaIDFAAQDDAABnhYQBmhYAAijQAAk+l5AAIjcAAgAhbMiIiqnBIqqAAIigHBIjTAAIJq5DIDDAAIJpZDgAp2nzIj7KqIIuAAIj9qqQgNglgLhGIgFAAQgLBEgOAngA7JMiIAA2aItAAAIAAWaIi8AAIAA5DIS4AAIAAZDg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-275.8,-80.2,551.7,160.4);


(lib.orange = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#268E39").s().p("A1FKKIAA0TMAqLAAAIAAUTg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-135,-65,270,130);


(lib.O = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EE7F35").s().p("AlvJCQjuiZg8kWQg9kUCYjwQCYjvEVg9QESg9DuCZQDuCZA9EWQA9EUiZDwQiYDvkUA9QhPAShKAAQi+AAiqhug");
	this.shape.setTransform(0.0102,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-68.3,-68.7,136.7,137.5);


(lib.m3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.m13_230();
	this.instance.parent = this;
	this.instance.setTransform(-115,-63);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-115,-63,230,126);


(lib.m2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.m12_230();
	this.instance.parent = this;
	this.instance.setTransform(-115,-63);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-115,-63,230,126);


(lib.m1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.m11_230();
	this.instance.parent = this;
	this.instance.setTransform(-115,-63);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-115,-63,230,126);


(lib.M = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#952F80").s().p("AkBHjQjGhshCjZQhBjZBrjHQBrjJDYhBQDXhBDHBrQDHBsBBDZQBBDZhrDIQhrDIjYBBQhSAZhOAAQiCAAh8hDg");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-54.6,-54.9,109.30000000000001,109.9);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.logos_240x400();
	this.instance.parent = this;
	this.instance.setTransform(-120,-200);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-120,-200,240,400);


(lib.TRC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E12731").s().p("AiWDjIAAnFICJAAQBPAAAqAkQArAlAABCQAABCgtApQgsAqhMABIg9AAIAACkgAhLABIAxAAQAvAAAagWQAZgWAAgpQAAhQhdAAIg2AAg");
	this.shape.setTransform(582.75,1.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E12731").s().p("AglDjIAAmGIiCAAIAAg/IFPAAIAAA/IiDAAIAAGGg");
	this.shape_1.setTransform(542.55,1.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E12731").s().p("ABrDjIAAjFIjVAAIAADFIhMAAIAAnFIBMAAIAAC/IDVAAIAAi/IBMAAIAAHFg");
	this.shape_2.setTransform(499.15,1.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#E12731").s().p("Ah/DjIAAnFID0AAIAAA/IioAAIAACCICbAAIAAA+IibAAIAACHICzAAIAAA/g");
	this.shape_3.setTransform(458.45,1.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#E12731").s().p("ACSEhIAAh8IlnAAIAAnEIBMAAIAAGCIDVAAIAAmCIBLAAIAAGCIA/AAIAAC+g");
	this.shape_4.setTransform(414.975,7.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#E12731").s().p("AB4ErIAAkuQAAgqADgPIgCAAQgEANgJANIjZFNIhTAAIAAnFIBJAAIAAEfQAAAxgCARIABAAQAGgMAKgQIDSlFIBXAAIAAHFgAhTjfQgggcgEgvIA9AAQAFA5A4ABQAZgBASgPQAQgOAEgcIA9AAQgFAvgjAcQgiAbgyABQg0gBgigbg");
	this.shape_5.setTransform(342,-6.15);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E12731").s().p("ACMDjIAAnFIBLAAIAAHFgAjWDjIAAnFIBLAAIAAC3IBOAAQBIgBAoAiQAoAhAAA+QAABCgrAmQgpAmhJAAgAiLClIBCAAQApAAAWgTQAWgUAAgkQAAhJhVgBIhCAAg");
	this.shape_6.setTransform(288.425,1.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E12731").s().p("ABrDjIAAjFIjVAAIAADFIhLAAIAAnFIBLAAIAAC/IDVAAIAAi/IBLAAIAAHFg");
	this.shape_7.setTransform(235.875,1.05);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#E12731").s().p("AiYDjIAAnFIBMAAIAAC3IBMAAQBJgBAoAiQAoAhAAA+QAABCgqAmQgrAmhIAAgAhMClIBBAAQAoAAAWgTQAXgUAAgkQAAhJhXgBIg/AAg");
	this.shape_8.setTransform(192.525,1.05);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#E12731").s().p("AjCDfIAAhAQAOAIATAAQAUAAARgXQARgXARheQAShdAVijID2AAIAAHFIhLAAIAAmFIhvAAQgTCXgQBRQgNBDgOAhQgOAhgXAPQgXAPghAAQgbAAgVgHg");
	this.shape_9.setTransform(144.875,1.375);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#E12731").s().p("Ah/DjIAAnFID0AAIAAA/IioAAIAACCICbAAIAAA+IibAAIAACHICyAAIAAA/g");
	this.shape_10.setTransform(105.9,1.05);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#E12731").s().p("AglDjIAAmGIiCAAIAAg/IFPAAIAAA/IiCAAIAAGGg");
	this.shape_11.setTransform(68.05,1.05);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#E12731").s().p("ACBDjIgoh0IiyAAIgnB0IhTAAICqnFIBVAAICoHFgAgHiDIg/C1ICLAAIg/i1QgEgIgCgUIAAAAQgDAPgEANg");
	this.shape_12.setTransform(30.9,1.05);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#E12731").s().p("ABKDjIidjQQgHgJgEgHIgBAAIAADgIhMAAIAAnFIBMAAIAADVIABAAQADgGAIgKICXjFIBaAAIixDaIC/Drg");
	this.shape_13.setTransform(-9.275,1.05);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#E12731").s().p("Ah/DjIAAnFID0AAIAAA/IioAAIAACCICbAAIAAA+IibAAIAACHICyAAIAAA/g");
	this.shape_14.setTransform(-48.9,1.05);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#E12731").s().p("AjCDfIAAhAQAOAIAUAAQATAAARgXQAQgWAShfQAShhAVifID2AAIAAHFIhLAAIAAmFIhuAAQgXCogNBAQgNBDgOAhQgNAggYAQQgXAPghAAQgbAAgVgHg");
	this.shape_15.setTransform(-94.075,1.375);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#E12731").s().p("AiZDjIAAnFICQAAQBCAAAmAdQAmAdAAAuQAAAmgWAdQgWAcgmANIAAAAQAuAFAdAeQAcAdAAAuQAAA7guAkQguAkhFAAgAhOCnIBBAAQApAAAXgTQAXgUAAgjQAAhGhhAAIg3AAgAhOglIAxAAQAnAAAWgSQAWgSAAgiQAAg7hNAAIg3AAg");
	this.shape_16.setTransform(-134.025,1.05);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#E12731").s().p("AiUDSIAAhJQA1AmBFAAQArAAAbgUQAagVAAgjQAAhMhqAAIg0AAIAAg6IAxAAQAsAAAZgTQAZgTAAgjQAAgdgVgSQgVgSgkAAQg4AAg2AiIAAhDQA2gcBDAAQBEAAAnAgQAnAfAAAyQAABYhXAXIAAACQAvAFAbAcQAcAeAAArQAAA/gvAlQguAlhQAAQhQAAgsgZg");
	this.shape_17.setTransform(-174.625,1.025);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#E12731").s().p("ACCDjIgqh0IixAAIgoB0IhSAAICrnFIBTAAICpHFgAgHiDIg+C1ICJAAIg/i1QgCgIgDgUIgBAAQgCAPgEANg");
	this.shape_18.setTransform(-215.65,1.05);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#E12731").s().p("AiWDjIAAnFICKAAQBMAAAsAkQArAlAABCQAABCgtApQgsAqhNABIg8AAIAACkgAhLABIAwAAQAwAAAZgWQAagWAAgpQAAhQhcAAIg3AAg");
	this.shape_19.setTransform(-251.6,1.05);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#E12731").s().p("AhWAbIAAg1ICtAAIAAA1g");
	this.shape_20.setTransform(-286.8,6.025);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#E12731").s().p("AieCrQg7g/AAhmQAAhtA8hBQA8hCBmAAQBfAAA7BAQA7BAAABlQAABvg8BAQg8BBhjAAQhiAAg7hAgAhjh5QgnAvAABLQAABMAmAuQAmAuA+AAQA/AAAngsQAlgsAAhPQAAhRglgsQgkgshAAAQg+AAgnAug");
	this.shape_21.setTransform(-326.15,1.025);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#E12731").s().p("AiZDjIAAnFICQAAQBBAAAnAdQAmAdAAAuQAAAmgWAdQgWAcgmANIAAAAQAuAFAdAeQAcAdAAAuQAAA7guAkQguAkhFAAgAhOCnIBAAAQAqAAAXgTQAXgUAAgjQAAhGhhAAIg3AAgAhOglIAxAAQAnAAAWgSQAWgSAAgiQAAg7hNAAIg3AAg");
	this.shape_22.setTransform(-370.475,1.05);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#E12731").s().p("AieCrQg7hAAAhlQAAhtA8hBQA8hCBnAAQBfAAA7BAQA6BAAABlQAABvg8BAQg8BBhjAAQhiAAg7hAgAhjh5QgnAvAABLQAABMAmAuQAmAuA+AAQA/AAAngsQAlgsAAhPQAAhQgkgtQglgshAAAQg+AAgnAug");
	this.shape_23.setTransform(-417.625,1.025);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#E12731").s().p("Ah9DjIAAnFID7AAIAABBIivAAIAAGEg");
	this.shape_24.setTransform(-455.925,1.05);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#E12731").s().p("AiWDjIAAnFICJAAQBNAAAsAkQArAlAABCQAABCgtApQgsAqhNABIg8AAIAACkgAhLABIAxAAQAvAAAZgWQAagWAAgpQAAhQhcAAIg3AAg");
	this.shape_25.setTransform(-492.9,1.05);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#E12731").s().p("AieCrQg7hAAAhlQAAhtA8hBQA8hCBmAAQBgAAA7BAQA6BAAABlQAABvg8BAQg8BBhjAAQhiAAg7hAgAhjh5QgnAvAABLQAABMAmAuQAmAuA9AAQBAAAAmgsQAmgsAAhPQAAhQgkgtQglgshAAAQg+AAgnAug");
	this.shape_26.setTransform(-539.775,1.025);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#E12731").s().p("AglDjIAAmGIiCAAIAAg/IFPAAIAAA/IiCAAIAAGGg");
	this.shape_27.setTransform(-581.05,1.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-597.8,-36,1195.6999999999998,72.1);


(lib.girl = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.d11_230();
	this.instance.parent = this;
	this.instance.setTransform(-115,-63);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-115,-63,230,126);


(lib.G = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#96C145").s().p("AlUMtQiehDh5h6Qh6h6hCieQhFikAAi0QAAiyBFikQBCifB6h6QB5h6CehDQCihFCyAAQCyAACjBFQCeBDB5B6QB6B6BCCfQBFCkAACyQAAC0hFCkQhCCeh6B6Qh5B6ieBDQijBGiyAAQiyAAiihGg");
	this.shape.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-87.7,-88.2,175.5,176.5);


(lib.flow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.d12_230();
	this.instance.parent = this;
	this.instance.setTransform(-115,-63);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-115,-63,230,126);


(lib.C = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#009FDF").s().p("AiRMFQibgdiFhaQiEhZhXiDQhUiBgeiWQgeiYAdiVQAdicBYiFQBYiFCEhXQB/hVCXgeQCWgeCUAcQCbAdCFBaQCEBZBXCDQBUCBAeCWQAeCYgdCVQgdCchYCFQhYCFiEBXQh/BViWAeQhOAQhNAAQhIAAhIgOg");
	this.shape.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-78.2,-78.7,156.5,157.4);


(lib.B = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#005E97").s().p("AiRKeQkUg9iZjvQiYjwA9kUQA8kWDuiZQDuiZETA9QEUA9CYDvQCZDwg9EUQg8EWjuCZQiqBui+AAQhLAAhOgSg");
	this.shape.setTransform(0.0128,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-68.3,-68.7,136.7,137.5);


(lib.sobir = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AALAkIAAgrIAAAAIgVArIgOAAIAAhGIAOAAIAAArIAVgrIAOAAIAABGg");
	this.shape.setTransform(100.9017,34.9551,2.8056,2.8056);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AARAkIABgwIgNAwIgJAAIgNgwIABAwIgOAAIAAhGIASAAIAMAzIAAAAIANgzIASAAIAABGg");
	this.shape_1.setTransform(81.8237,34.9551,2.8056,2.8056);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAKAkIAAgaIgIAAIgKAaIgPAAIANggQgEgCgCgEQgDgFAAgGQAAgKAGgGQAGgFAJAAIAWAAIAABGgAgDgVQgCADAAAGQAAAGACACQACAEAEAAIAHAAIAAgYIgIAAQgCAAgDADg");
	this.shape_2.setTransform(62.9561,34.9551,2.8056,2.8056);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AALAkIAAgrIgBAAIgUArIgOAAIAAhGIAOAAIAAArIAAAAIAVgrIAOAAIAABGg");
	this.shape_3.setTransform(47.6657,34.9551,2.8056,2.8056);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AALAkIAAgeIgVAAIAAAeIgOAAIAAhGIAOAAIAAAeIAVAAIAAgeIAOAAIAABGg");
	this.shape_4.setTransform(30.2009,34.9551,2.8056,2.8056);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgUAkIAAhGIApAAIAAAKIgbAAIAAASIAXAAIAAAKIgXAAIAAAVIAbAAIAAALg");
	this.shape_5.setTransform(14.7,34.9551,2.8056,2.8056);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AALAkIAAgcIgLACQgLAAgGgHQgGgDgBgNIAAgVIAPAAIAAAVQAAAHACACQADAEAEAAIALgCIAAggIANAAIAABGg");
	this.shape_6.setTransform(-1.7127,34.9551,2.8056,2.8056);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgUAkIAAhGIApAAIAAAKIgbAAIAAASIAXAAIAAAKIgXAAIAAAVIAbAAIAAALg");
	this.shape_7.setTransform(-17.2837,34.9551,2.8056,2.8056);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AANAkIAAg8IgOAAIAAAVQAAAVgFAJQgFAIgLABIgDAAIAAgLIABAAQAGgCACgFQABgEAAgRIAAgfIAqAAIAABGg");
	this.shape_8.setTransform(-34.2575,34.9551,2.8056,2.8056);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgWAkIAAhGIAVAAQAKAAAGAEQAGAFAAAKQAAAFgCAEQgCAEgFACQAGAAADAEQACAGAAAEQAAALgGAFQgFAFgLABgAgIAZIAJAAQAEAAACgDQACgCAAgGQAAgFgBgCQgCgDgEAAIgKAAgAgIgFIAIAAQADABACgDQACgCAAgFQAAgFgCgCQgDgCgDgBIgHAAg");
	this.shape_9.setTransform(-50.4598,34.9551,2.8056,2.8056);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgPAfQgHgEAAgLIANAAQAAAEADACQADAEADAAQAFAAABgEQADgCAAgEQAAgHgCgCQgCgDgEAAIgHAAIAAgJIAHAAQADAAACgDQACgCAAgFQAAgFgCgCQgDgCgDgBQgCABgDACQgCADAAAEIgOAAQAAgKAGgFQAGgGAJABQAKAAAGAEQAGAGAAAKQAAAEgCAEQgCAEgFADQAFABADAEQACAFAAAGQAAAKgHAFQgGAFgKABQgJAAgGgGg");
	this.shape_10.setTransform(-66.6621,34.9551,2.8056,2.8056);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AANAkIgEgQIgRAAIgEAQIgOAAIAUhGIANAAIAUBGgAgGAJIANAAIgHgYIAAAAg");
	this.shape_11.setTransform(-82.3032,34.9551,2.8056,2.8056);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgXAkIAAhGIAYAAQALgBAGAHQAGAGAAAKQAAALgGAEQgGAHgLAAIgKAAIAAAagAgJAAIAKAAQAFAAACgEQACgCAAgGQAAgGgCgCQgCgDgFgBIgKAAg");
	this.shape_12.setTransform(-98.4353,34.9551,2.8056,2.8056);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AALAiIAAgpIgBAAIgUApIgMAAIAAhDIAMAAIAAApIABAAIAUgpIAMAAIAABDg");
	this.shape_13.setTransform(101.2524,4.6547,2.8056,2.8056);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AARAiIABgtIgBAAIgNAtIgIAAIgMgtIAAAAIAAAtIgMAAIAAhDIAQAAIAMAxIAAAAIAMgxIARAAIAABDg");
	this.shape_14.setTransform(83.1563,4.6547,2.8056,2.8056);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AALAiIAAgpIgBAAIgUApIgNAAIAAhDIANAAIAAApIABAAIAUgpIAMAAIAABDg");
	this.shape_15.setTransform(64.92,4.6547,2.8056,2.8056);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAKAiIAAgdIgTAAIAAAdIgOAAIAAhDIAOAAIAAAdIATAAIAAgdIAOAAIAABDg");
	this.shape_16.setTransform(48.367,4.6547,2.8056,2.8056);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AARAqIAAgRIggAAIAAARIgMAAIgCgbIAFAAQADgDACgHQACgGABgNIABgbIAlAAIAAA4IAIAAIgCAbgAgEgOQAAAIgCAJQgBAHgDAFIAUAAIAAgtIgNAAg");
	this.shape_17.setTransform(31.1127,6.9693,2.8056,2.8056);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgQAcQgGgGgBgMIAAgSQABgMAGgHQAGgGAKAAQALAAAGAGQAGAIAAALIAAASQAAALgGAHQgGAHgLAAQgKAAgGgHgAgHgTQgDADAAAIIAAASQAAAGADAEQADAEAEAAQAGAAABgEQAEgDAAgHIAAgSQAAgIgEgDQgBgEgGAAQgEAAgDAEg");
	this.shape_18.setTransform(14.4194,4.6547,2.8056,2.8056);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgSAiIAAhDIAlAAIAAALIgYAAIAAA4g");
	this.shape_19.setTransform(0.2512,4.6547,2.8056,2.8056);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgQAcQgHgHAAgLIAAgSQAAgLAHgIQAGgGAKAAQALAAAGAGQAHAHAAAMIAAASQAAAMgHAGQgGAHgLAAQgKAAgGgHgAgHgTQgCADAAAIIAAASQAAAHACADQACAEAFAAQAFAAADgEQADgEgBgGIAAgSQABgIgDgDQgDgEgFAAQgFAAgCAEg");
	this.shape_20.setTransform(-14.7587,4.6547,2.8056,2.8056);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgVAiIAAhDIAUAAQAJABAGAEQAGAEAAAJQAAAFgCAEQgCAEgEACQAEAAAEAEQACAFAAAFQAAAJgGAFQgFAFgKABgAgIAXIAJAAQAEAAABgDQADgCAAgEQAAgEgCgDQgBgDgEAAIgKAAgAgIgFIAHAAQAEAAABgCQADgCAAgEQAAgFgDgCQgCgCgDAAIgHAAg");
	this.shape_21.setTransform(-30.0491,4.6547,2.8056,2.8056);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgRAcQgFgGAAgMIAAgSQAAgMAFgHQAHgGAKAAQAKAAAHAGQAGAIABALIAAASQgBALgGAHQgGAHgLAAQgKAAgHgHgAgHgTQgCACgBAJIAAASQABAGACAEQADAEAEAAQAEAAADgEQADgDAAgHIAAgSQAAgJgDgCQgCgEgFAAQgFAAgCAEg");
	this.shape_22.setTransform(-45.7604,4.6547,2.8056,2.8056);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AAKAiIAAgdIgTAAIAAAdIgOAAIAAhDIAOAAIAAAdIATAAIAAgdIANAAIAABDg");
	this.shape_23.setTransform(-62.0328,4.6547,2.8056,2.8056);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AAMAiIgDgPIgRAAIgEAPIgNAAIAThDIANAAIATBDgAgFAJIALAAIgGgXIAAAAg");
	this.shape_24.setTransform(-84.4074,4.6547,2.8056,2.8056);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgOAdQgHgEAAgKIANAAQAAADADADQACADADAAQAEAAACgDQADgDAAgEQAAgEgCgDQgCgDgFAAIgGAAIAAgJIAGAAQAFAAABgCQACgDAAgFQAAgDgCgDQgCgCgEAAQgDAAgCACQgCACAAAEIgNAAIAAAAQAAgJAGgEQAFgGAJABQAKgBAFAGQAGAEAAAJQAAAFgCAEQgEAEgDACQAFABACAEQADAEAAAGQAAAJgGAFQgHAGgJAAQgJgBgFgFg");
	this.shape_25.setTransform(-99.6978,4.6547,2.8056,2.8056);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AANAvIAAgiIgKAAIgOAiIgUAAIARgpQgFgEgEgFQgCgGAAgIQAAgOAIgIQAHgHAOAAIAcAAIAABdgAgEgcQgDAEAAAIQAAAHADAEQADAFAFAAIAJAAIAAggIgJAAQgFAAgDAEg");
	this.shape_26.setTransform(97.7454,-29.2228,2.8056,2.8056);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgWAoQgIgKAAgQIAAgbQAAgQAIgKQAJgJANAAQAPAAAIAIQAHAIABAQIgBABIgRAAQAAgLgCgDQgDgEgIAAQgEAAgEAFQgEAFAAAKIAAAbQABALADAEQADAFAGAAQAHAAADgEQACgEAAgJIARAAIABAAQAAAQgIAIQgHAIgPAAQgNAAgKgJg");
	this.shape_27.setTransform(78.8077,-29.2228,2.8056,2.8056);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AAXAvIACg/IgBAAIgSA/IgLAAIgSg/IAAAAIABA/IgSAAIAAhdIAYAAIAQBEIAAAAIARhEIAYAAIAABdg");
	this.shape_28.setTransform(54.3289,-29.2228,2.8056,2.8056);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgbAvIAAhdIA3AAIAAAOIgkAAIAAAYIAeAAIAAAOIgeAAIAAAaIAkAAIAAAPg");
	this.shape_29.setTransform(31.4634,-29.2228,2.8056,2.8056);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AASAvIgFgUIgYAAIgFAUIgTAAIAbhdIASAAIAaBdgAgIAMIARAAIgJggIAAAAg");
	this.shape_30.setTransform(10.4215,-29.2228,2.8056,2.8056);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgfAvIAAhdIAgAAQAPAAAIAIQAIAIAAAOQAAAOgIAHQgJAIgOAAIgNAAIAAAigAgMgBIANAAQAHAAACgEQADgEAAgHQAAgHgDgEQgDgFgGAAIgNAAg");
	this.shape_31.setTransform(-8.6565,-29.2228,2.8056,2.8056);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AAPAvIAAg6IgBAAIgcA6IgSAAIAAhdIASAAIAAA5IABAAIAcg5IASAAIAABdg");
	this.shape_32.setTransform(-31.7325,-29.2228,2.8056,2.8056);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgeAvIAAhdIA0AAIAAAOIghAAIAAAUIALAAQAOAAAIAJQAJAGAAAOQAAANgJAJQgJAIgNAAgAgLAgIALAAQAGAAADgEQADgEAAgHQAAgHgDgEQgDgEgGAAIgLAAg");
	this.shape_33.setTransform(-53.1251,-29.2228,2.8056,2.8056);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgXAnQgJgJAAgRIAAgZQAAgQAJgKQAJgKAOAAQAPAAAJAKQAJAKAAAQIAAAZQAAARgJAJQgJAKgPAAQgOAAgJgKgAgKgcQgEAGAAAKIAAAZQABAKAEAGQACAFAHAAQAIAAADgFQAEgGAAgKIAAgZQAAgKgEgGQgDgFgIAAQgGAAgEAFg");
	this.shape_34.setTransform(-75.3594,-29.2228,2.8056,2.8056);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgVAoQgJgJAAgRIAAgbQAAgRAJgJQAIgJANAAQAPAAAIAIQAIAJAAAPIAAABIgSAAQAAgKgDgEQgCgEgIAAQgFAAgDAFQgEAFAAAKIAAAbQAAAKAEAFQADAFAGAAQAHAAADgEQACgFAAgIIASAAIAAAAQAAAQgIAIQgIAIgOAAQgNAAgJgJg");
	this.shape_35.setTransform(-96.6117,-29.2228,2.8056,2.8056);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 2
	this.instance = new lib.yellow("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.8519,0.9692);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-115,-63,230,126);


(lib.LOGO_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_73 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(73).call(this.frame_73).wait(1));

	// nhw
	this.instance = new lib.TRC("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-0.25,476.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(67).to({_off:false},0).wait(1).to({y:420.7226,alpha:0.7359},0).wait(1).to({y:409.2278,alpha:0.8887},0).wait(1).to({y:404.118,alpha:0.9566},0).wait(1).to({y:401.8468,alpha:0.9868},0).wait(1).to({y:401.0102,alpha:0.9979},0).wait(1).to({y:400.85,alpha:1},0).wait(1));

	// парк
	this.instance_1 = new lib.Park("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(440.1,246.35);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(60).to({_off:false},0).wait(1).to({y:204.6682,alpha:0.6999},0).wait(1).to({y:195.2962,alpha:0.8573},0).wait(1).to({y:190.7455,alpha:0.9337},0).wait(1).to({y:188.4236,alpha:0.9727},0).wait(1).to({y:187.3158,alpha:0.9913},0).wait(1).to({y:186.8866,alpha:0.9985},0).wait(1).to({y:186.8,alpha:1},0).wait(7));

	// радуга
	this.instance_2 = new lib.Raduga("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-297.3,257.85);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(50).to({_off:false},0).wait(1).to({y:221.0514,alpha:0.6179},0).wait(1).to({y:211.5085,alpha:0.7782},0).wait(1).to({y:206.1909,alpha:0.8675},0).wait(1).to({y:202.93,alpha:0.9222},0).wait(1).to({y:200.8862,alpha:0.9566},0).wait(1).to({y:199.6263,alpha:0.9777},0).wait(1).to({y:198.8893,alpha:0.9901},0).wait(1).to({y:198.5012,alpha:0.9966},0).wait(1).to({y:198.3368,alpha:0.9994},0).wait(1).to({y:198.3,alpha:1},0).wait(14));

	// Layer_5
	this.instance_3 = new lib.Rcopy("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(0.35,-546.1,2.2692,3.6393,0,0,0,0.1,2.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1).to({regX:0,regY:-54,scaleX:2.3146,scaleY:3.5996,x:0.05,y:-706.6},0).wait(1).to({scaleX:2.4386,scaleY:3.4911,x:0,y:-586.25},0).wait(1).to({scaleX:2.6366,scaleY:3.3178,x:-0.1,y:-394.25},0).wait(1).to({regY:2.3,scaleX:3,scaleY:2.9999,x:-0.05,y:126.9},0).to({regX:0.1,regY:2.4,scaleX:3.7843,scaleY:2.3983,x:0.35,y:127.2},3).wait(1).to({regX:0,regY:-54,scaleX:3.685,scaleY:2.4745,x:-0.05,y:-12.35},0).wait(1).to({regX:0.1,regY:2.4,scaleX:2.9999,scaleY:2.9999,x:0.25,y:127.1},0).wait(10).to({regX:0,regY:2.3,scaleX:3,x:-0.05,y:126.9},0).wait(1).to({regY:-54,scaleX:3.3619,scaleY:2.276,y:-1.3},0).wait(1).to({scaleX:3.4632,scaleY:2.0734,y:10.1},0).wait(1).to({regY:2.3,scaleX:3.4999,scaleY:2,x:-0.1,y:126.85},0).wait(1).to({regY:-54,scaleX:5.8814,scaleY:7.4317,x:0.2,y:-290.1,alpha:0.1507},0).wait(1).to({scaleX:6.1467,scaleY:8.0368,x:0.25,y:-324,alpha:0.0561},0).wait(1).to({scaleX:6.2446,scaleY:8.2602,y:-336.5,alpha:0.0212},0).wait(1).to({scaleX:6.2843,scaleY:8.3507,y:-341.6,alpha:0.0071},0).wait(1).to({scaleX:6.2993,scaleY:8.3849,y:-343.5,alpha:0.0017},0).wait(1).to({scaleX:6.3036,scaleY:8.3947,y:-344.05,alpha:0.0002},0).wait(1).to({regX:0.1,regY:2.5,scaleX:6.3041,scaleY:8.3958,x:0.3,y:128.6,alpha:0},0).wait(45));

	// Layer_6
	this.instance_4 = new lib.Rwhite("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(-0.1,269.9,4.9999,5);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(24).to({_off:false},0).to({alpha:0},2).wait(48));

	// R
	this.instance_5 = new lib.R("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(-0.3,1.05,1.6,1.6);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(25).to({_off:false},0).to({scaleX:1,scaleY:1,guide:{path:[-0.2,1.3,-43.7,55.9,-106.3,84.6,-169,113.4,-239.5,110.9,-311.6,108.3,-378.9,73.3,-449.7,36.6,-504.7,-31]}},19,cjs.Ease.cubicOut).wait(30));

	// Layer_1_copy
	this.instance_6 = new lib.Rwhite("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(-95.45,79.3,4.9999,5);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(25).to({_off:false},0).to({x:-0.1,y:269.9,alpha:0},2).wait(47));

	// O
	this.instance_7 = new lib.O("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(-0.4,0.75);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(26).to({_off:false},0).to({guide:{path:[-0.4,0.8,70.5,25.3,132.9,20.1,190.8,15.3,237.1,-14.5,280.5,-42.5,308.8,-89,336.2,-133.9,345.4,-189,354.7,-244.3,344.2,-300.2,333.2,-358.5,302.3,-408.4,269.2,-461.8,217.1,-499.3,160.5,-540,85.8,-558.7,-68.7,-597.3,-175.6,-543.1,-261.7,-499.5,-313.3,-398.1,-350.7,-324.6,-366.9,-228.5,-372.1,-197.3,-374.4,-167.2,-375.9,-149.3,-375.9,-139.3]}},21,cjs.Ease.cubicOut).wait(27));

	// Layer_1_copy
	this.instance_8 = new lib.Rwhite("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(51.8,15,4.9999,5);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(26).to({_off:false},0).to({x:-0.1,y:269.9,alpha:0},2).wait(46));

	// Y
	this.instance_9 = new lib.Y("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(-0.9,0.6);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(27).to({_off:false},0).to({guide:{path:[-0.9,0.7,-0.9,55,-14.6,106.5,-27.8,156.4,-53.2,200.4,-78.1,243.8,-112.9,278.5,-147.8,313.2,-190.1,336.7,-233.3,360.7,-281.1,371.3,-330.6,382.3,-382,378.3,-493.6,369.7,-599.2,294,-652.3,256,-681.2,199.6,-708,147.2,-711.8,83.8,-715.4,23.8,-698,-38.2,-681,-98.9,-646.7,-151.4,-611.8,-205,-564.8,-240.8,-515.3,-278.6,-459.2,-291.3,-398.9,-304.9,-337,-287.7,-269.6,-269,-204.8,-215.1]}},21,cjs.Ease.cubicOut).wait(26));

	// Layer_1_copy_copy
	this.instance_10 = new lib.Rwhite("synched",0);
	this.instance_10.parent = this;
	this.instance_10.setTransform(-68,224.15,4.9999,5);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(27).to({_off:false},0).to({x:-0.1,y:269.9,alpha:0},2).wait(45));

	// G
	this.instance_11 = new lib.G("synched",0);
	this.instance_11.parent = this;
	this.instance_11.setTransform(-0.9,0.6);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(28).to({_off:false},0).to({guide:{path:[-0.8,0.6,-0.8,14.9,10.2,40.1,18.2,58.5,36.8,92.6,65.7,145.3,69.9,153.3,88.9,189.6,99.8,217,128.8,290.5,112.4,334,91.7,388.7,-0.8,403.8,-39.4,410.1,-70.8,399.9,-100.6,390.2,-121.6,366.5,-141.9,343.7,-152.1,310.2,-162.3,277,-161.4,237.3,-160.6,196.8,-148.4,154.2,-135.8,109.8,-112.2,67.4,-59.7,-26.7,34,-91.5,92.5,-131.8,136.4,-179.6,181.2,-228.3,200.4,-273.8,221,-322.2,208.3,-357.9,194.5,-397,142.2,-416,107,-428.8,78,-416.5,52.4,-405.6,33.5,-376.1,16.8,-350,7.6,-313.3,-0.6,-280.7,-0.8,-248.5]}},18,cjs.Ease.cubicOut).wait(28));

	// C
	this.instance_12 = new lib.C("synched",0);
	this.instance_12.parent = this;
	this.instance_12.setTransform(-0.9,0.6);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(29).to({_off:false},0).to({guide:{path:[-0.8,0.7,-46.1,87.7,-32.3,173.9,-25.8,213.9,-6.7,250.1,12.1,285.5,41.8,314.6,71.4,343.6,109.5,363.9,148.4,384.5,193.1,394.4,289.2,415.7,393.1,385,501,353.1,594.4,284.4,688.3,215.3,742.9,126.9,800.9,33.1,801.2,-61.4,801.6,-165.1,731.8,-254.6,664.9,-340.3,567.5,-353.6,489.5,-364.2,395.6,-328.3,328.6,-302.7,260.3,-256.3,238.9,-241.8,220,-227,212.6,-221,205.3,-215.1]}},18,cjs.Ease.cubicOut).wait(27));

	// B
	this.instance_13 = new lib.B("synched",0);
	this.instance_13.parent = this;
	this.instance_13.setTransform(-0.1,0.7);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(30).to({_off:false},0).to({guide:{path:[0,0.8,247.6,33.8,349.8,52.4,394.3,60.6,430.6,69.2,506.9,87.3,546.5,107.2,578.2,123.1,593.7,142.8,609.1,162.4,610.1,187.6,611,212,598.3,244.4,586.4,274.6,560.9,316,537.2,354.3,495.2,383.1,456.7,409.5,407.8,424.7,361.6,439,314.8,440.8,268.4,442.5,232.3,431.6,194.6,420.2,176.4,397.3,156.8,372.5,163.4,338,170.7,300,209.4,253.9,252,203,330.5,145.1,383.9,105.6,430.6,69.2,658.3,-108.4,723.3,-212.4,759.7,-270.7,743.8,-304.3,728.6,-336.5,665.9,-345.5,654.4,-347.9,635.4,-347.7,597.5,-347.3,560.5,-334.1,508.7,-315.7,466.1,-274.6,413,-223.2,377.5,-139]}},18,cjs.Ease.cubicOut).wait(26));

	// M
	this.instance_14 = new lib.M("synched",0);
	this.instance_14.parent = this;
	this.instance_14.setTransform(-0.9,0.6);
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(31).to({_off:false},0).to({guide:{path:[-0.9,0.6,-123.1,54.9,-249,90.4,-366.1,123.5,-475.6,137.4,-579.6,150.6,-663.2,145,-745.2,139.6,-794.3,116.9,-844.4,93.7,-851.6,56.3,-859.2,16.9,-817.6,-33.1,-772.9,-86.9,-675,-147.8,-568.8,-213.9,-406.4,-284.4,-70.8,-429.1,181.1,-460.3,293.4,-474.2,382.3,-464.2,465.6,-454.8,523.2,-425,577.8,-396.7,604.7,-352.5,630.8,-309.6,628,-256.3,625.2,-203.3,594.1,-146.4,562.1,-88,503.9,-32.3]}},18,cjs.Ease.cubicOut).wait(25));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-889.4,-950.5,1768.6,1462.7);


(lib.adrs = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgbApQgIgLAAgWIAAg7IATAAIAAA7QAAARADAFQAEAHAIAAQAGAAAFgDQAFgFACgFIAAhLIATAAIAABlIgRAAIgBgOQgEAHgGAFQgHAEgHAAQgNAAgIgLg");
	this.shape.setTransform(86.0391,20.6061,1.7999,1.7999);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgWA0IAAhlIARAAIABAPQAEgJAEgDQAFgFAHAAIAHABIgDARIgIAAQgHAAgDADQgDAEgCAGIAABIg");
	this.shape_1.setTransform(73.0797,20.2461,1.7999,1.7999);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgJAKIAAgSIATAAIAAASg");
	this.shape_2.setTransform(62.6403,27.8507,1.7999,1.7999);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAQBJIgaguIgIAAIAAAuIgTAAIAAiRIATAAIAABUIAIAAIAVgnIAXAAIgeAsIAiA4g");
	this.shape_3.setTransform(51.7958,16.3763,1.7999,1.7999);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgWA0IAAhlIARAAIACAPQADgJAEgDQAFgFAHAAIAHABIgDARIgJAAQgFAAgEADQgDAEgCAGIAABIg");
	this.shape_4.setTransform(38.4314,20.2461,1.7999,1.7999);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgcAtQgIgIAAgOQAAgPAKgIQAJgHASAAIAOAAIAAgLQAAgJgEgFQgEgFgHAAQgGAAgFAEQgEAFAAAHIgSAAIgBgBQAAgLAKgKQAKgJAOAAQAPAAAKAJQAJAJAAAQIAAAvIADAWIgTAAIgCgHIAAgHQgEAHgHAEQgFAFgJAAQgLAAgIgIgAgMAJQgFAGAAAIQAAAHAEAEQADAEAGAAQAGAAAFgEQAFgDADgHIAAgVIgPAAQgGAAgGAGg");
	this.shape_5.setTransform(24.2121,20.4261,1.7999,1.7999);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgkBHIAAiLIARAAIABALQACgFAIgFQAFgDAHAAQAPAAAJANQAKANAAAWIAAANQAAATgKAMQgJAMgPAAQgGAAgGgDQgGgDgDgFIAAAwgAgKg0QgFADgCAHIAAAyQACAFAEAEQAFADAGAAQAJAAAEgJQAGgIAAgMIAAgNQAAgNgGgLQgFgJgIAAQgHAAgDADg");
	this.shape_6.setTransform(8.1029,23.756,1.7999,1.7999);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgcAtQgIgIAAgOQAAgPAKgIQAJgHASAAIAOAAIAAgLQAAgJgEgFQgFgFgGAAQgHAAgEAEQgEAFAAAHIgSAAIgBgBQAAgLAKgKQAKgJAOAAQAQAAAJAJQAJAJAAAQIAAAvIADAWIgTAAIgCgHIAAgHQgFAHgGAEQgGAFgHAAQgNAAgHgIgAgMAJQgFAGAAAIQAAAGADAFQAEAEAGAAQAFAAAGgEQAGgEACgGIAAgVIgPAAQgHAAgFAGg");
	this.shape_7.setTransform(-8.7262,20.4261,1.7999,1.7999);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgOBGQgIgCgGgDIAFgOQAEADAGABIAMACQAKAAAEgHQAFgGABgNIAAgKQgFAHgFACQgGADgGAAQgQAAgJgMQgJgNAAgSIAAgNQABgVAIgOQAJgNAQAAQAHAAAGADQAGAEAEAHIABgMIARAAIAABkQAAATgLALQgLALgRAAQgHAAgGgCgAgNgvQgFAKABAOIAAANQgBANAFAHQAEAIAKAAQAGAAAFgDQADgCAEgHIAAgxQgEgHgDgDQgEgDgHAAQgJAAgFAJg");
	this.shape_8.setTransform(-25.4654,23.9359,1.7999,1.7999);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgbApQgIgLAAgWIAAg7IATAAIAAA7QAAAQAEAGQADAHAIAAQAGAAAEgDQAGgEACgGIAAhLIATAAIAABlIgRAAIgBgOQgEAHgHAFQgGAEgHAAQgOAAgHgLg");
	this.shape_9.setTransform(-41.9796,20.6061,1.7999,1.7999);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgbA9QgJgOAAgWIAAgCQAAgYAJgOQAIgPAQAAQAGAAAGADQAFADAFAGIAAg3IATAAIAACRIgSAAIgBgLQgFAHgEADQgIADgFAAQgQAAgIgNgAgNgFQgEAKAAASIAAACQgBAQAFAJQAEAJAKAAQAGAAAEgDQAFgEADgFIAAgxQgDgFgFgFQgDgDgHAAQgJAAgFAKg");
	this.shape_10.setTransform(-59.1238,16.5563,1.7999,1.7999);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgdAtQgHgJAAgNQAAgPAKgIQAKgHAQAAIAPAAIAAgLQAAgJgEgFQgEgFgHAAQgHAAgEAEQgEAEAAAIIgSAAIAAgBQgBgLAKgKQAKgJAOAAQAPAAAJAJQAKAJAAAQIAAA6IADALIgUAAIgCgOQgEAHgGAEQgGAFgIAAQgMAAgIgIgAgMAJQgFAFAAAJQAAAHAEAEQACAEAHAAQAEAAAHgEQAEgDAEgHIAAgVIgPAAQgHAAgFAGg");
	this.shape_11.setTransform(-75.233,20.4261,1.7999,1.7999);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgWA0IAAhlIARAAIACAPQADgIAEgEQAFgFAHAAIAHABIgCARIgJAAQgHAAgDADQgDAEgCAGIAABIg");
	this.shape_12.setTransform(-87.9223,20.2461,1.7999,1.7999);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAJBEIAAggIgxAAIgBgKIAxhdIAUAAIAABZIAOAAIAAAOIgOAAIAAAggAgWAWIAfAAIAAg+IgBAAg");
	this.shape_13.setTransform(90.3589,-24.3017,1.7999,1.7999);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgPBFQgGgBgGgDIACgOQAGADAFABQAEABAHAAQAJAAAHgKQAGgJAAgSIAAgHQgDAGgGAEQgHAEgFAAQgQAAgKgNQgJgNAAgUQAAgVAKgOQAMgOAPAAQARAAALANQAKAOAAAZIAAAjQAAAZgMAOQgLANgSAAgAgNgtQgFAJAAAPQAAAPAFAIQAEAJAJAAQAHAAAEgEQAFgEADgGIAAgQQAAgRgFgKQgFgJgJAAQgHAAgGAKg");
	this.shape_14.setTransform(73.2147,-24.3017,1.7999,1.7999);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgLAXIAGgbIAAgSIARAAIAAASIgMAbg");
	this.shape_15.setTransform(53.7307,-11.5223,1.7999,1.7999);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgcAtQgIgIAAgOQAAgOAKgJQAKgIARABIAOAAIAAgKQAAgJgEgGQgEgFgHAAQgGAAgFAFQgEAEAAAHIgSAAIgBgBQAAgMAKgIQAKgKAOABQAPAAAKAIQAJAJAAARIAAAuIADAVIgTAAIgCgGIAAgHQgEAHgHAEQgFAEgJAAQgMAAgHgHgAgMAJQgEAGgBAIQAAAHAEAEQADAEAGABQAGAAAFgFQAGgEACgGIAAgVIgPAAQgGABgGAFg");
	this.shape_16.setTransform(42.6612,-21.1068,1.7999,1.7999);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AARAzIAAgrIghAAIAAArIgTAAIAAhlIATAAIAAAsIAhAAIAAgsIATAAIAABlg");
	this.shape_17.setTransform(26.102,-21.1518,1.7999,1.7999);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AARAzIAAhEIAAAAIghBEIgTAAIAAhlIATAAIAABEIAAAAIAhhEIATAAIAABlg");
	this.shape_18.setTransform(9.0929,-21.1518,1.7999,1.7999);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AARAzIAAhWIghAAIAABWIgTAAIAAhlIBHAAIAABlg");
	this.shape_19.setTransform(-7.9163,-21.1518,1.7999,1.7999);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgZAoQgLgLAAgVIAAgOQAAgTALgOQAKgNAQABQASAAAIALQAKALAAAVIAAAMIg2AAIAAAEQAAANAGAJQAGAJAJAAQAIgBAGgCQAFgDAGgEIAGALQgGAGgHADQgIADgLAAQgRAAgLgMgAgLgdQgFAGgBAPIAjAAIAAgFQAAgKgEgIQgFgGgIAAQgIAAgEAIg");
	this.shape_20.setTransform(-24.0705,-21.1068,1.7999,1.7999);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgqBEIAAiHIAsAAQATAAALALQALAMAAASQAAATgLAKQgLALgTAAIgZAAIAAA2gAgXAAIAZAAQALAAAFgHQAGgHAAgMQAAgMgGgHQgFgIgLAAIgZAAg");
	this.shape_21.setTransform(-40.8997,-24.3017,1.7999,1.7999);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgJAJIAAgSIATAAIAAASg");
	this.shape_22.setTransform(-62.9036,-13.7272,1.7999,1.7999);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AAVAzIAAhWIgYAAIAAAdQAAAcgHAPQgIAOgRAAIgEAAIAAgPIADAAQAIAAADgJQADgJAAgYIAAgsIA+AAIAABlg");
	this.shape_23.setTransform(-76.1779,-21.1518,1.7999,1.7999);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgbBHIgGgCIADgNIACAAIADAAQAGAAADgFQADgEACgHIADgKIgfhlIAVAAIASBJIAAAAIAThJIAVAAIgkB1QgDAKgGAIQgGAIgLgBg");
	this.shape_24.setTransform(-90.7572,-17.417,1.7999,1.7999);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 2
	this.instance = new lib.orange("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.8519,0.9692);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-115,-63,230,126);


// stage content:
(lib.NY_240x400_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// контур
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3A3838").s().p("AyvfQMAAAg+fMAlfAAAMAAAA+fgAylfGMAlLAAAMAAAg+LMglLAAAg");
	this.shape.setTransform(120,200);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(330));

	// Layer_5
	this.instance = new lib.logos("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(120,200);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(259).to({_off:false},0).wait(71));

	// LOGO
	this.instance_1 = new lib.LOGO_2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(120.05,-42,0.14,0.14,0,0,0,0.4,-748.2);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(152).to({_off:false},0).to({_off:true},107).wait(71));

	// Layer 1
	this.instance_2 = new lib.sobir("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(356,201,1,1,0,0,0,0,1);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(132).to({_off:false},0).to({x:120},5,cjs.Ease.circInOut).wait(117).to({startPosition:0},0).to({alpha:0},5).to({_off:true},1).wait(70));

	// адрес
	this.instance_3 = new lib.adrs("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(-116,332);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(142).to({_off:false},0).to({x:120},5,cjs.Ease.circInOut).wait(107).to({startPosition:0},0).to({alpha:0},5).to({_off:true},1).wait(70));

	// Layer_4
	this.instance_4 = new lib.m3("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(120,332,0.0022,1);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(78).to({_off:false},0).to({scaleX:1},5).wait(54).to({startPosition:0},0).to({x:355},5,cjs.Ease.circInOut).to({_off:true},118).wait(70));

	// сапоги
	this.instance_5 = new lib.shoes("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(120,332);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(15).to({_off:false},0).wait(58).to({startPosition:0},0).to({scaleX:0.0022},5).to({_off:true},1).wait(251));

	// Layer_3
	this.instance_6 = new lib.m2("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(120,200,0.0022,1);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(68).to({_off:false},0).to({scaleX:1},5).wait(54).to({startPosition:0},0).to({x:-116},5,cjs.Ease.circInOut).to({_off:true},128).wait(70));

	// цветы
	this.instance_7 = new lib.flow("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(120,200);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(7).to({_off:false},0).wait(56).to({startPosition:0},0).to({scaleX:0.0022},5).to({_off:true},1).wait(261));

	// Layer_2
	this.instance_8 = new lib.m1("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(120,68,0.0022,1);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(58).to({_off:false},0).to({scaleX:1},5).wait(84).to({startPosition:0},0).to({alpha:0},5).to({_off:true},108).wait(70));

	// голова
	this.instance_9 = new lib.girl("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(120,68);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(53).to({startPosition:0},0).to({scaleX:0.0022},5).to({_off:true},1).wait(271));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-111,129.7,582,270.3);
// library properties:
lib.properties = {
	id: 'D07B62C12C961C48BCDD200239C3446B',
	width: 240,
	height: 400,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/NY_240x400_2_atlas_.jpg", id:"NY_240x400_2_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['D07B62C12C961C48BCDD200239C3446B'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;